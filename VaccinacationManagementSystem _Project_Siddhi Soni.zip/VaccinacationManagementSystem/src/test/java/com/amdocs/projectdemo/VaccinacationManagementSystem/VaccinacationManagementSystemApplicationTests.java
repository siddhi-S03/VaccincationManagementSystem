package com.amdocs.projectdemo.VaccinacationManagementSystem;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class VaccinacationManagementSystemApplicationTests {

	@Test
	void contextLoads() {
	}

}
