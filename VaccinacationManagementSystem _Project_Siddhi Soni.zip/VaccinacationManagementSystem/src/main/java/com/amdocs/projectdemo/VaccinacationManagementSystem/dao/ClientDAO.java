package com.amdocs.projectdemo.VaccinacationManagementSystem.dao;

import java.util.List;

import com.amdocs.projectdemo.VaccinationManagementSystem.entity.Client;

public interface ClientDAO {

	List<Client> getClient();

	Client getClient(int clientId);

	void deleteClient(int clientId);
	
	Client save(Client theClient);

}
