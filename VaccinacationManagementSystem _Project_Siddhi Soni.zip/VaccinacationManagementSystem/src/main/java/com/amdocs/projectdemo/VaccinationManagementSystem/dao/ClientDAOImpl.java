package com.amdocs.projectdemo.VaccinationManagementSystem.dao;

import java.util.List;

import org.hibernate.Session;

import com.amdocs.projectdemo.VaccinacationManagementSystem.dao.ClientDAO;
import com.amdocs.projectdemo.VaccinationManagementSystem.entity.Client;

import jakarta.persistence.EntityManager;
import jakarta.persistence.Query;
import jakarta.transaction.Transactional;

public class ClientDAOImpl implements ClientDAO {

    private EntityManager entityManager;

    public ClientDAOImpl(EntityManager theEntityManager) {
        this.entityManager = theEntityManager;
    }

    @Override
    @Transactional
    public List<Client> getClient() {
        Session currentSession = entityManager.unwrap(Session.class);
        Query theQuery = currentSession.createQuery("from Client", Client.class);
        List<Client> clients = theQuery.getResultList();
        return clients;
    }

    @Override
    @Transactional
    public Client getClient(int clientId) {
        Session currentSession = entityManager.unwrap(Session.class);
        Client client = currentSession.get(Client.class, clientId);
        return client;
    }

    @Transactional
    public Client save(Client theClient) {
        Session currentSession = entityManager.unwrap(Session.class);
        currentSession.saveOrUpdate(theClient);
        return theClient;
    }

    @Override
    @Transactional
    public void deleteClient(int clientId) {
        Session currentSession = entityManager.unwrap(Session.class);
        Query theQuery = currentSession.createQuery("delete from Client where id=:cliId");
        theQuery.setParameter("cliId", clientId);
        theQuery.executeUpdate();
    }
}
