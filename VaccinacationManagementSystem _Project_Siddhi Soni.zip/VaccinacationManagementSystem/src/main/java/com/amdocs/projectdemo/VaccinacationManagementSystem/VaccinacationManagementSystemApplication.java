package com.amdocs.projectdemo.VaccinacationManagementSystem;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class VaccinacationManagementSystemApplication {

	public static void main(String[] args) {
		SpringApplication.run(VaccinacationManagementSystemApplication.class, args);
	}

}
