
package com.amdocs.projectdemo.VaccinationManagementSystem.entity;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.SequenceGenerator;
import jakarta.persistence.Table;

@Entity
@Table(name="Clients")
//@SequenceGenerator(name="MySequence",sequenceName="client_sequence,initialValue=50,allocationSize=1")
public class Client {
	@Id
	//@GeneratedValue(strategy=GenerationType.SEQUENCE,generator="MySequence")
	@Column(name="ID")
	private int id;
	@Column(name="FIRST_NAME")
	private String firstName;
	@Column(name="LAST_NAME")
	private String lastName;
	@Column(name="VACCINE_STATUS")
	private String VaccineStauts;

public  Client()
{

}

public int getId() {
	return id;
}

public void setId1(int id) {
	this.id = id;
}

public String getFirstName() {
	return firstName;
}

public void setFirstName(String firstName) {
	this.firstName = firstName;
}

public String getLastName() {
	return lastName;
}

public void setLastName(String lastName) {
	this.lastName = lastName;
}

public String getVaccineStauts() {
	return VaccineStauts;
}

public void setVaccineStauts(String vaccineStauts) {
	VaccineStauts = vaccineStauts;
}

@Override
public String toString() {
	return "Client [id=" + id + ", firstName=" + firstName + ", lastName=" + lastName + ", VaccineStauts="
			+ VaccineStauts + "]";
}

public void setId(int id2) {
	// TODO Auto-generated method stub
	
}

}
